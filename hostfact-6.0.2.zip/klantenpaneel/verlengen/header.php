<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="author" content="HostFact B.V." />
	<title>Direct online verlengen</title>
	<link type="text/css" href="css/style.css" rel="stylesheet"/>
	<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
	<script type="text/javascript" src="js/jquery-ui-1.10.4.custom.min.js"></script>
	<script type="text/javascript" src="js/renew.js"></script>
</head>

<body>

	<div id="wrapper">
		
		<?php if(CLIENTAREA_LOGO_URL){ ?>
		<div class="noborder_box">
			<img style="width: 100%;" src="<?php echo CLIENTAREA_LOGO_URL; ?>" width="730" />
		</div>
		<?php } ?>