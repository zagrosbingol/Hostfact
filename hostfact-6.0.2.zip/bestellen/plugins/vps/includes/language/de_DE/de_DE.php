<?php


$_LANG = array();

$_LANG['vps'] = 'VPS';
$_LANG['vps product'] = 'VPS';
$_LANG['vps hostname'] = 'Hostname';
$_LANG['vps image'] = 'Betriebssystem';

$_LANG['please enter a hostname'] = 'Kein Hostname angegeben';