<?php


$_LANG = array();

$_LANG['vps'] = 'VPS';
$_LANG['vps product'] = 'VPS';
$_LANG['vps hostname'] = 'Hostnaam';
$_LANG['vps image'] = 'Besturingssysteem';

$_LANG['please enter a hostname'] = 'Er is geen hostnaam opgegeven';