<?php


$_LANG = array();

$_LANG['vps'] = 'VPS';
$_LANG['vps product'] = 'VPS';
$_LANG['vps hostname'] = 'Nom d\'hôte';
$_LANG['vps image'] = 'Système d\'exploitation';

$_LANG['please enter a hostname'] = 'Pas de nom d\'hôte spécifié';